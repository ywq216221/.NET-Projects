﻿using CommonServiceLocator;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using StoreManagement.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StoreManagement.ViewModel
{
    public class CustomerViewModel : ViewModelBase
    {
        public CustomerViewModel()
        {
            CustomerList = new CustomerService().Select();
        }
        private Customer customer = new Customer();
        public Customer Customer
        {
            get { return customer; }
            set { customer = value; RaisePropertyChanged(); }
        }

        private List<Customer> customerList = new List<Customer>();

        public List<Customer> CustomerList
        {
            get { return customerList; }
            set { customerList = value; RaisePropertyChanged(); }
        }

        //增加
        public RelayCommand<UserControl> AddCommand
        {
            get
            {
                var command = new RelayCommand<UserControl>((view) =>
                {
                    if (string.IsNullOrEmpty(Customer.Name) == true)
                    {
                        MessageBox.Show("不能为空");
                        return;
                    }

                    Customer.InsertDate = DateTime.Now;

                    CustomerService service = new CustomerService();
                    int count = service.Insert(Customer);
                    if (count > 0)
                    {
                        CustomerList = service.Select();
                        MessageBox.Show("操作成功");
                        Customer = new Customer();
                    }
                    else
                    {
                        MessageBox.Show("操作失败");
                    }
                });

                return command;
            }
        }

        //修改
        public RelayCommand<Button> EditCommand
        {
            get
            {
                var command = new RelayCommand<Button>((view) =>
                {
                    var old = view.Tag as Customer;
                    if (old == null) return;
                    var model = ServiceLocator.Current.GetInstance<EditCustomerViewModel>();
                    model.Customer = old;
                    var window = new EditCustomerWindow();
                    window.ShowDialog();
                    CustomerList = new CustomerService().Select();
                });

                return command;
            }
        }

        //删除
        public RelayCommand<Button> DeleteCommand
        {
            get
            {
                var command = new RelayCommand<Button>((view) =>
                {
                    if (MessageBox.Show("是否执行操作?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        var old = view.Tag as Customer;
                        if (old == null) return;

                        CustomerService service = new CustomerService();
                        int count = service.Delete(old);
                        if (count > 0)
                        {
                            CustomerList = service.Select();
                            MessageBox.Show("操作成功");
                        }
                        else
                        {
                            MessageBox.Show("操作失败");
                        }
                    }
                });

                return command;
            }
        }
    }
}
