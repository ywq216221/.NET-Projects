﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreManagement.ViewModel
{
    public class QueryOutStoreViewModel : ViewModelBase
    {
        private string goodsName = string.Empty;
        /// <summary>
        /// 物资名称
        /// </summary>
        public string GoodsName
        {
            get { return goodsName; }
            set { goodsName = value; RaisePropertyChanged(); }
        }

        private List<OutStore> instores = null;
        /// <summary>
        /// 查询结果
        /// </summary>
        public List<OutStore> Outstores
        {
            get { return instores; }
            set { instores = value; RaisePropertyChanged(); }
        }

        //查询命令

        public RelayCommand QueryCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    if (string.IsNullOrEmpty(goodsName)) return;
                    var list = new OutStoreService().Select();
                    Outstores = list.Where(t => t.Name.Contains(GoodsName)).ToList();
                });
            }
        }
    }
}
