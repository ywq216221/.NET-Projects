﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreManagement.Service
{
    public class GoodsService : IService<Goods>
    {
        public int Delete(Goods t)
        {
            using (StoreDBEntities db = new StoreDBEntities())
            {
                db.Entry(t).State = System.Data.Entity.EntityState.Deleted;
                return db.SaveChanges();
            }
        }

        public int Insert(Goods t)
        {
            using (StoreDBEntities db = new StoreDBEntities())
            {
                db.Entry(t).State = System.Data.Entity.EntityState.Added;
                return db.SaveChanges();
            }
        }

        public Goods Select(int Id)
        {
            using (StoreDBEntities db = new StoreDBEntities())
            {
                return db.Goods.FirstOrDefault(item => item.Id == Id);
            }
        }

        public Goods Select(string Name)
        {
            using (StoreDBEntities db = new StoreDBEntities())
            {
                return db.Goods.FirstOrDefault(item => item.Name == Name);
            }
        }

        public List<Goods> Select()
        {
            using (StoreDBEntities db = new StoreDBEntities())
            {
                return db.Goods.ToList();
            }
        }
        public int Update(Goods t)
        {
            using (StoreDBEntities db = new StoreDBEntities())
            {

                db.Entry(t).State = System.Data.Entity.EntityState.Modified;
                return db.SaveChanges();
            }
        }
    }
}
