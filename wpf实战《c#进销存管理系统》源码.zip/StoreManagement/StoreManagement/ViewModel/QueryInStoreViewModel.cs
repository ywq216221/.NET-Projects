﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreManagement.ViewModel
{
    public class QueryInStoreViewModel : ViewModelBase
    {
        
        private string goodsName = string.Empty;
        /// <summary>
        /// 物资名称
        /// </summary>
        public string GoodsName
        {
            get { return goodsName; }
            set { goodsName = value; RaisePropertyChanged(); }
        }

        private List<InStore> instores = null;
        /// <summary>
        /// 查询结果
        /// </summary>
        public List<InStore> Instores
        {
            get { return instores; }
            set { instores = value; RaisePropertyChanged(); }
        }

        //查询命令

        public RelayCommand QueryCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    if (string.IsNullOrEmpty(goodsName)) return;
                    var list = new InStoreService().Select();
                    Instores = list.Where(t => t.Name.Contains(GoodsName)).ToList();
                });
            }
        }
    }
}
