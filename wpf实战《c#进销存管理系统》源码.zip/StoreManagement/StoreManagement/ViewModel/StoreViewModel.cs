﻿using CommonServiceLocator;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using StoreManagement.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StoreManagement.ViewModel
{
    public class StoreViewModel : ViewModelBase
    {
        public StoreViewModel()
        {
            StoreList = new StoreService().Select();
        }
        private Store store = new Store();
        public Store Store
        {
            get { return store; }
            set { store = value; RaisePropertyChanged(); }
        }

        private List<Store> storeList = new List<Store>();

        public List<Store> StoreList
        {
            get { return storeList; }
            set { storeList = value; RaisePropertyChanged(); }
        }

        //增加
        public RelayCommand<UserControl> AddCommand
        {
            get
            {
                var command = new RelayCommand<UserControl>((view) =>
                {
                    if (string.IsNullOrEmpty(Store.Name) == true)
                    {
                        MessageBox.Show("不能为空");
                        return;
                    }

                    Store.InsertDate = DateTime.Now;

                    var service = new StoreService();
                    int count = service.Insert(Store);
                    if (count > 0)
                    {
                        StoreList = service.Select();
                        MessageBox.Show("操作成功");
                        Store = new Store();
                    }
                    else
                    {
                        MessageBox.Show("操作失败");
                    }
                });

                return command;
            }
        }

        //修改
        public RelayCommand<Button> EditCommand
        {
            get
            {
                var command = new RelayCommand<Button>((view) =>
                {
                    var old = view.Tag as Store;
                    if (old == null) return;
                    var model = ServiceLocator.Current.GetInstance<EditStoreViewModel>();
                    model.Store = old;
                    var window = new EditStoreWindow();
                    window.ShowDialog();
                    StoreList = new StoreService().Select();
                });

                return command;
            }
        }

        //删除
        public RelayCommand<Button> DeleteCommand
        {
            get
            {
                var command = new RelayCommand<Button>((view) =>
                {
                    if (MessageBox.Show("是否执行操作?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        var old = view.Tag as Store;
                        if (old == null) return;

                        var service = new StoreService();
                        int count = service.Delete(old);
                        if (count > 0)
                        {
                            StoreList = service.Select();
                            MessageBox.Show("操作成功");
                        }
                        else
                        {
                            MessageBox.Show("操作失败");
                        }
                    }
                });

                return command;
            }
        }
    }
}
