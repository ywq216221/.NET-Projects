﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StoreManagement.ViewModel
{
    public class EditCustomerViewModel : ViewModelBase
    {
        private Customer customer = new Customer();
        public Customer Customer
        {
            get { return customer; }
            set { customer = value; RaisePropertyChanged(); }
        }



        //修改客户
        public RelayCommand<Window> EditCommand
        {
            get
            {
                var command = new RelayCommand<Window>((view) =>
                {
                    if (string.IsNullOrEmpty(Customer.Name) == true)
                    {
                        MessageBox.Show("不能为空");
                        return;
                    }

                    CustomerService service = new CustomerService();
                    int count = service.Update(Customer);
                    if (count > 0)
                    {
                        MessageBox.Show("操作成功");
                    }
                    else
                    {
                        MessageBox.Show("操作失败");
                    }
                });

                return command;
            }
        }
    }
}
