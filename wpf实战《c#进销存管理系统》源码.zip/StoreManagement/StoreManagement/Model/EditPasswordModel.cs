﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreManagement.Model
{
    public class EditPasswordModel : ObservableObject
    {
        private string oldPassword = "";
        public string OldPassword
        {
            get { return oldPassword; }
            set { oldPassword = value; RaisePropertyChanged(); }
        }

        private string newPassword = "";
        public string NewPassword
        {
            get { return newPassword; }
            set { newPassword = value; RaisePropertyChanged(); }
        }

        private string password2 = "";
        public string Password2
        {
            get { return password2; }
            set { password2 = value; RaisePropertyChanged(); }
        }
    }
}
