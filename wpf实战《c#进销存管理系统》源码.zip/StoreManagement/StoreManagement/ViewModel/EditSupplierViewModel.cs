﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StoreManagement.ViewModel
{
    public class EditSupplierViewModel : ViewModelBase
    {
        private Supplier supplier = new Supplier();
        public Supplier Supplier
        {
            get { return supplier; }
            set { supplier = value; RaisePropertyChanged(); }
        }

        //修改用户
        public RelayCommand<Window> EditCommand
        {
            get
            {
                var command = new RelayCommand<Window>((window) =>
                {
                    if (string.IsNullOrEmpty(Supplier.Name) == true
                    || string.IsNullOrEmpty(Supplier.Contact) == true
                    || string.IsNullOrEmpty(Supplier.Telephone) == true)
                    {
                        MessageBox.Show("不能为空");
                        return;
                    }

                    var service = new SupplierService();
                    int count = service.Update(Supplier);
                    if (count > 0)
                    {
                        MessageBox.Show("修改成功");
                        window.Close();
                    }
                    else
                    {
                        MessageBox.Show("修改失败");
                    }
                });

                return command;
            }
        }


        //取消
        public RelayCommand<Window> CancelCommand
        {
            get
            {
                var command = new RelayCommand<Window>((window) =>
                {
                    window.Close();
                });

                return command;
            }
        }
    }
}
