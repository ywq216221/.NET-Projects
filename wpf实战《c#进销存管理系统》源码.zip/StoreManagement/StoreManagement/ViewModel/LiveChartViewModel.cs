﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using LiveCharts;
using LiveCharts.Wpf;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreManagement.ViewModel
{
    public class LiveChartViewModel : ViewModelBase
    {
        //物资库存柱状
        private IChartValues goodsChartValues = new ChartValues<double>();
        public IChartValues GoodsChartValues
        {
            get { return goodsChartValues; }
            set { goodsChartValues = value;RaisePropertyChanged(); }
        }

        private List<string> goodsLabes = new List<string>();
        public List<string> GoodsLabes
        {
            get { return goodsLabes; }
            set { goodsLabes = value;RaisePropertyChanged(); }
        }

        //物资入库流水折线
        public SeriesCollection GoodsInStoreSeries { get; set; } = new SeriesCollection();
        public AxesCollection GoodsInStoreAxis { get; set; } = new AxesCollection();

        //物资出库流水折线
        public SeriesCollection GoodsOutStoreSeries { get; set; } = new SeriesCollection();
        public AxesCollection GoodsOutStoreAxis { get; set; } = new AxesCollection();

        //客户出库饼图
        public SeriesCollection CustomerPieSeries { get; set; } = new SeriesCollection();
        public RelayCommand LoadCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                  
                    GoodsChartValues.Clear();
                    GoodsLabes.Clear();
                    var goodsList = new GoodsService().Select();                   
                    var instoreList = new InStoreService().Select();
                    var outstoreList = new OutStoreService().Select();
                    var customers = new CustomerService().Select();
                    goodsList.ForEach(goods => 
                    {
                        //物资库存柱状
                        GoodsChartValues.Add(goods.Quant);
                        GoodsLabes.Add(goods.Name);

                        //物资入库流水折线
                        var instores = instoreList.FindAll(item => item.GoodsSerial == goods.Serial);
                        var inserise = new LineSeries() { Title = goods.Name, Values = new ChartValues<double>() };
                        instores.ForEach(item =>
                        {
                            inserise.Values.Add(item.Number);
                        });
                        GoodsInStoreSeries.Add(inserise);

                        //物资出库流水折线
                        var outstores = outstoreList.FindAll(item => item.GoodsSerial == goods.Serial);
                        var outserise = new LineSeries() { Title = goods.Name, Values = new ChartValues<double>() };
                        outstores.ForEach(item =>
                        {
                            outserise.Values.Add(item.Number);
                        });
                        GoodsOutStoreSeries.Add(outserise);
                    });

                    CustomerPieSeries.Clear();
                    customers.ForEach(item =>
                    {
                        var list = outstoreList.FindAll(outstore => outstore.CustomerId == item.Id);
                        var sum = list.Sum(t => t.Number);
                        var pieSeries = new PieSeries
                        {
                            Title = item.Name,
                            Values = new ChartValues<double>() { sum }
                        };
                        CustomerPieSeries.Add(pieSeries);
                    });





                });
            }
        }
    }
}
