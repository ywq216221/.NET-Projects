/*
  In App.xaml:
  <Application.Resources>
      <vm:ViewModelLocator xmlns:vm="clr-namespace:StoreManagement"
                           x:Key="Locator" />
  </Application.Resources>
  
  In the View:
  DataContext="{Binding Source={StaticResource Locator}, Path=ViewModelName}"

  You can also use Blend to do all this with the tool's support.
  See http://www.galasoft.ch/mvvm
*/

using CommonServiceLocator;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Ioc;

namespace StoreManagement.ViewModel
{
    /// <summary>
    /// This class contains static references to all the view models in the
    /// application and provides an entry point for the bindings.
    /// </summary>
    public class ViewModelLocator
    {
        /// <summary>
        /// Initializes a new instance of the ViewModelLocator class.
        /// </summary>
        public ViewModelLocator()
        {
            ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);

            SimpleIoc.Default.Register<MainViewModel>();
            SimpleIoc.Default.Register<LoginViewModel>();
            SimpleIoc.Default.Register<EditPasswordViewModel>();
            SimpleIoc.Default.Register<EditUserViewModel>();
            SimpleIoc.Default.Register<GoodsTypeViewModel>();
            SimpleIoc.Default.Register<EditGoodsTypeViewModel>();
            SimpleIoc.Default.Register<StoreViewModel>();
            SimpleIoc.Default.Register<EditStoreViewModel>();
            SimpleIoc.Default.Register<SupplierViewModel>();
            SimpleIoc.Default.Register<EditSupplierViewModel>();
            SimpleIoc.Default.Register<SpecViewModel>();
            SimpleIoc.Default.Register<EditSpecViewModel>();
            SimpleIoc.Default.Register<GoodsViewModel>();
            SimpleIoc.Default.Register<EditGoodsViewModel>();
            SimpleIoc.Default.Register<InStoreViewModel>();
            SimpleIoc.Default.Register<SelectGoodsViewModel>();
            SimpleIoc.Default.Register<CustomerViewModel>();
            SimpleIoc.Default.Register<EditCustomerViewModel>();
            SimpleIoc.Default.Register<OutStoreViewModel>();
            SimpleIoc.Default.Register<InventoryViewModel>();
            SimpleIoc.Default.Register<QuantViewModel>();
            SimpleIoc.Default.Register<QueryInStoreViewModel>();
            SimpleIoc.Default.Register<QueryOutStoreViewModel>();
            SimpleIoc.Default.Register<UserInfoViewModel>();
            SimpleIoc.Default.Register<LiveChartViewModel>();
            SimpleIoc.Default.Register<BackupViewModel>();
            
        }

        public MainViewModel Main
        {
            get
            {
                return ServiceLocator.Current.GetInstance<MainViewModel>();
            }
        }

        public LoginViewModel Login
        {
            get
            {
                return ServiceLocator.Current.GetInstance<LoginViewModel>();
            }
        }

        public EditPasswordViewModel EditPassword
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditPasswordViewModel>();
            }
        }

        public EditUserViewModel EditUser
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditUserViewModel>();
            }
        }

        public GoodsTypeViewModel GoodsType
        {
            get
            {
                return ServiceLocator.Current.GetInstance<GoodsTypeViewModel>();
            }
        }

        public EditGoodsTypeViewModel EditGoodsType
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditGoodsTypeViewModel>();
            }
        }

        public StoreViewModel Store
        {
            get
            {
                return ServiceLocator.Current.GetInstance<StoreViewModel>();
            }
        }
        public EditStoreViewModel EditStore
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditStoreViewModel>();
            }
        }
        public SupplierViewModel Supplier
        {
            get
            {
                return ServiceLocator.Current.GetInstance<SupplierViewModel>();
            }
        }
        public EditSupplierViewModel EditSupplier
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditSupplierViewModel>();
            }
        }
        public SpecViewModel Spec
        {
            get
            {
                return ServiceLocator.Current.GetInstance<SpecViewModel>();
            }
        }
        public EditSpecViewModel EditSpec
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditSpecViewModel>();
            }
        }
        public GoodsViewModel Goods
        {
            get
            {
                return ServiceLocator.Current.GetInstance<GoodsViewModel>();
            }
        }

        public EditGoodsViewModel EditGoods
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditGoodsViewModel>();
            }
        }

        public InStoreViewModel InStore
        {
            get
            {
                return ServiceLocator.Current.GetInstance<InStoreViewModel>();
            }
        }

        public SelectGoodsViewModel SelectGoods
        {
            get
            {
                return ServiceLocator.Current.GetInstance<SelectGoodsViewModel>();
            }
        }
        public CustomerViewModel Customer
        {
            get
            {
                return ServiceLocator.Current.GetInstance<CustomerViewModel>();
            }
        }

        public EditCustomerViewModel EditCustomer
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditCustomerViewModel>();
            }
        }

        public OutStoreViewModel OutStore
        {
            get
            {
                return ServiceLocator.Current.GetInstance<OutStoreViewModel>();
            }
        }

        public InventoryViewModel Inventory
        {
            get
            {
                return ServiceLocator.Current.GetInstance<InventoryViewModel>();
            }
        }
        public QuantViewModel Quant
        {
            get
            {
                return ServiceLocator.Current.GetInstance<QuantViewModel>();
            }
        }
        public QueryInStoreViewModel QueryInStore
        {
            get
            {
                return ServiceLocator.Current.GetInstance<QueryInStoreViewModel>();
            }
        }

        public QueryOutStoreViewModel QueryOutStore
        {
            get
            {
                return ServiceLocator.Current.GetInstance<QueryOutStoreViewModel>();
            }
        }
        public UserInfoViewModel UserInfo
        {
            get
            {
                return ServiceLocator.Current.GetInstance<UserInfoViewModel>();
            }
        }
        public LiveChartViewModel LiveChart
        {
            get
            {
                return ServiceLocator.Current.GetInstance<LiveChartViewModel>();
            }
        }
        public BackupViewModel Backup
        {
            get
            {
                return ServiceLocator.Current.GetInstance<BackupViewModel>();
            }
        }

        
        public static void Cleanup()
        {
            // TODO Clear the ViewModels
        }
    }
}