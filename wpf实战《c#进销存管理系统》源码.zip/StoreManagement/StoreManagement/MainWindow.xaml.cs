﻿using StoreManagement.View;
using StoreManagement.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StoreManagement
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Loaded += (s, e) =>
            {
                IndexView indexView = new IndexView();
                indexView.OnClick += (viewName) =>
                {
                    Assembly assembly = Assembly.GetExecutingAssembly(); // 获取当前程序集 
                    var space = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Namespace;
                    var path = space + ".View." + viewName;
                    dynamic obj = assembly.CreateInstance(path);
                    if (obj == null) return;
                    container.Content = obj;
                };

                container.Content = indexView;

                AutoMapper7.Configration.Configure();//实例化Mapper
            };
        }

        //Exit
        private void TextBlock_MouseUp(object sender, MouseButtonEventArgs e)
        {
            App.Current.Shutdown();
        }

        //修改密码
        private void TextBlock_MouseUp_1(object sender, MouseButtonEventArgs e)
        {
            var window = new EditPasswordWindow();
            window.ShowDialog();
        }

        //修改用户
        private void TextBlock_MouseUp_2(object sender, MouseButtonEventArgs e)
        {
            var window = new EditUserWindow();
            window.ShowDialog();
        }       
             

        private void StoreView_Checked(object sender, RoutedEventArgs e)
        {
            var button = sender as RadioButton;
            if (button == null) return;

            Assembly assembly = Assembly.GetExecutingAssembly(); // 获取当前程序集 
            var space = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Namespace;
            var path = space + ".View." + button.Name;
            dynamic obj = assembly.CreateInstance(path);
            if (obj == null) return;
            container.Content = obj;

            //快捷菜单
            if(obj is IndexView view)
            {
                view.OnClick += (viewName) =>
                {
                    path = space + ".View." + viewName;
                    obj = assembly.CreateInstance(path);
                    if (obj == null) return;
                    container.Content = obj;
                };
            }
        }

        private void RadioButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
