﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StoreManagement.ViewModel
{
    public class EditUserViewModel : ViewModelBase
    {
        private UserInfo user = AppData.Instance.User;
        public UserInfo User
        {
            get { return user; }
            set { user = value; RaisePropertyChanged(); }
        }

        //修改用户
        public RelayCommand<Window> EditUserCommand
        {
            get
            {
                var command = new RelayCommand<Window>((window) =>
                {
                    if (string.IsNullOrEmpty(User.Name) == true)
                    {
                        MessageBox.Show("名字不能为空");
                        return;
                    } 

                    UserInfoService userInfoService = new UserInfoService();
                    int count = userInfoService.Update(User);
                    if (count > 0)
                    {
                        MessageBox.Show("修改成功");
                        window.Close();
                    }
                    else
                    {
                        MessageBox.Show("修改失败");
                    }
                });

                return command;
            }
        }


        //取消
        public RelayCommand<Window> CancelCommand
        {
            get
            {
                var command = new RelayCommand<Window>((window) =>
                {
                    window.Close();                    
                });

                return command;
            }
        }
    }
}
