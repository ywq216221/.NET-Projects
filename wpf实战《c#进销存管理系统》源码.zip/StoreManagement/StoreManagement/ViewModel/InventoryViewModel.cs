﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using StoreManagement.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StoreManagement.ViewModel
{
    public class InventoryViewModel : ViewModelBase
    {

        //添加盘存记录
        public RelayCommand<UserControl> AddCommand
        {
            get
            {
                var command = new RelayCommand<UserControl>((obj) =>
                {
                    if (!(obj is InventoryView view)) return;
                    var GoodsList = new GoodsService().Select();
                    var inventoryService = new InventoryService();
                    foreach (var item in GoodsList)
                    {
                        var inventory = new Inventory();
                        inventory.Name = item.Name;
                        inventory.GoodsSerial = item.Serial;
                        inventory.Unit=item.Unit;
                        inventory.Quant = item.Quant;
                        inventory.InsertDate = DateTime.Now;
                        inventory.GoodsTypeId = item.GoodsTypeId;
                        inventory.SpecId = item.SpecId;
                        inventoryService.Insert(inventory);
                    }
                    MessageBox.Show("操作完成");
                    InventoryList = new InventoryService().Select();


                });

                return command;
            }
        }

        //加载数据
        public RelayCommand LoadCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    InventoryList = new InventoryService().Select();
                });
            }
        }


        private List<Inventory> inventoryList = new List<Inventory>();
        /// <summary>
        /// 盘存集合
        /// </summary>
        public List<Inventory> InventoryList
        {
            get { return inventoryList; }
            set { inventoryList = value; RaisePropertyChanged(); }
        }

    }
}
