﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Model;
using StoreManagement.Service;
using StoreManagement.View;
using StoreManagement.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StoreManagement.ViewModel
{
    public class InStoreViewModel : ViewModelBase
    {
        //添加
        public RelayCommand<UserControl> AddCommand
        {
            get
            {
                var command = new RelayCommand<UserControl>((obj) =>
                {
                    if (!(obj is InStoreView view)) return;
                    if (string.IsNullOrEmpty(InStore.Name) == true
                    || string.IsNullOrEmpty(InStore.GoodsSerial) == true)
                    {
                        MessageBox.Show("序号和名字不能为空");
                        return;
                    }

                    InStore.InsertDate = DateTime.Now;
                    InStore.UserInfoId = AppData.Instance.User.Id;

                    if(Store.Id == 0)
                    {
                        MessageBox.Show("仓库不能为空");
                        return;
                    }

                    if (Supplier.Id == 0)
                    {
                        MessageBox.Show("供应商不能为空");
                        return;
                    }

                    InStore.StoreId = Store.Id;
                    InStore.StoreName = Store.Name;
                    InStore.SupplierId = Supplier.Id;
                    InStore.SupplierName = Supplier.Name;

                    var newInstore = AutoMapper7.Configration.Mapper.Map<InStore>(InStore);
                    var service = new InStoreService();
                    int count = service.Insert(newInstore);
                    if (count > 0)
                    {
                        //及时更新当前物资的存量
                        if (Goods != null)
                        {
                            Goods.Quant += InStore.Number;
                            GoodsService goodsService = new GoodsService();
                            count = goodsService.Update(this.Goods);
                        }
                        InStoreList = new InStoreService().Select();
                        InStore = new InStoreEx();
                        MessageBox.Show("操作成功");

                    }
                    else
                    {
                        MessageBox.Show("操作失败");
                    }
                });

                return command;
            }
        }

        //加载数据
        public RelayCommand LoadCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    StoreList = new StoreService().Select();
                    SupplierList = new SupplierService().Select();
                    InStoreList = new InStoreService().Select();
                });
            }
        }

        private Store store = new Store();
        /// <summary>
        /// 当前仓库
        /// </summary>
        public Store Store
        {
            get { return store; }
            set { store = value; RaisePropertyChanged(); }
        }

        private List<Store> storeList = new List<Store>();
        /// <summary>
        /// 仓库集合
        /// </summary>
        public List<Store> StoreList
        {
            get { return storeList; }
            set { storeList = value; RaisePropertyChanged(); }
        }





        private Supplier supplier = new Supplier();
        /// <summary>
        /// 当前供应商
        /// </summary>
        public Supplier Supplier
        {
            get { return supplier; }
            set { supplier = value; RaisePropertyChanged(); }
        }



       

        private List<Supplier> supplierList = new List<Supplier>();
        /// <summary>
        /// 供应商集合
        /// </summary>
        public List<Supplier> SupplierList
        {
            get { return supplierList; }
            set { supplierList = value; RaisePropertyChanged(); }
        }


        private InStoreEx instore = new InStoreEx();
        public InStoreEx InStore
        {
            get { return instore; }
            set { instore = value; RaisePropertyChanged(); }
        }

        private List<InStore> inStoreList = new List<InStore>();
        /// <summary>
        /// 入库历史记录
        /// </summary>
        public List<InStore> InStoreList
        {
            get { return inStoreList; }
            set { inStoreList = value; RaisePropertyChanged(); }
        }


        private Goods goods = new Goods();
        /// <summary>
        /// 当前选择的资物对象
        /// </summary>
        public Goods Goods
        {
            get { return goods; }
            set { goods = value; RaisePropertyChanged(); }
        }

        public RelayCommand OpenSelectGoodsWindow
        {
            get
            {
                return new RelayCommand(() =>
                {
                    var window = new SelectGoodsWindow();
                    var result = window.ShowDialog();
                    if (result.HasValue && result.Value == true)
                    {
                        var vm = window.DataContext as SelectGoodsViewModel;
                        InStore.GoodsSerial = vm.Goods.Serial;
                        InStore.Name = vm.Goods.Name;
                        this.Goods = vm.Goods;
                    }
                });
            }
        }
    }
}
