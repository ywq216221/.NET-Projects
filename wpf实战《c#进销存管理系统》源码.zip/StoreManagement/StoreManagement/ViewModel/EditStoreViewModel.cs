﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StoreManagement.ViewModel
{
    public class EditStoreViewModel : ViewModelBase
    {
        private Store store = new Store();
        public Store Store
        {
            get { return store; }
            set { store = value; RaisePropertyChanged(); }
        }

        //修改
        public RelayCommand<Window> EditCommand
        {
            get
            {
                var command = new RelayCommand<Window>((window) =>
                {
                    if (string.IsNullOrEmpty(Store.Name) == true)
                    {
                        MessageBox.Show("不能为空");
                        return;
                    }

                    var service = new StoreService();
                    int count = service.Update(Store);
                    if (count > 0)
                    {
                        MessageBox.Show("修改成功");
                        window.Close();
                    }
                    else
                    {
                        MessageBox.Show("修改失败");
                    }
                });

                return command;
            }
        }
    }
}
