﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Control;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StoreManagement.ViewModel
{
    public class BackupViewModel : ViewModelBase
    {
        private List<Customer> customers = new List<Customer>();
        private List<Goods> goods = new List<Goods>();
        private List<GoodsType> goodsTypes = new List<GoodsType>();
        private List<InStore> inStores = new List<InStore>();
        private List<Inventory> inventories = new List<Inventory>();
        private List<OutStore> outStores = new List<OutStore>();
        private List<Spec> specs = new List<Spec>();
        private List<Store> stores = new List<Store>();
        private List<Supplier> suppliers = new List<Supplier>();
        private List<UserInfo> userInfos = new List<UserInfo>();


        private ObservableCollection<TabItem> tabItems = new ObservableCollection<TabItem>();
        public ObservableCollection<TabItem> TabItems
        {
            get { return tabItems; }
            set { tabItems = value;RaisePropertyChanged(); }
        }

        public RelayCommand LoadCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    customers = new CustomerService().Select();
                    goods = new GoodsService().Select();
                    goodsTypes = new GoodsTypeService().Select();
                    inStores = new InStoreService().Select();
                    inventories = new InventoryService().Select();
                    outStores = new OutStoreService().Select();
                    specs = new SpecService().Select();
                    stores = new StoreService().Select();
                    suppliers = new SupplierService().Select();
                    userInfos = new UserInfoService().Select();

                    tabItems.Add(new TabItem { Header= "customers", Content = new TableControl { DataContext = customers } });
                    tabItems.Add(new TabItem { Header= "goods", Content = new TableControl { DataContext = goods } });
                    tabItems.Add(new TabItem { Header= "goodsTypes", Content = new TableControl { DataContext = goodsTypes } });
                    tabItems.Add(new TabItem { Header= "inStores", Content = new TableControl { DataContext = inStores } });
                    tabItems.Add(new TabItem { Header= "inventories", Content = new TableControl { DataContext = inventories } });
                    tabItems.Add(new TabItem { Header= "outStores", Content = new TableControl { DataContext = outStores } });
                    tabItems.Add(new TabItem { Header= "specs", Content = new TableControl { DataContext = specs } });
                    tabItems.Add(new TabItem { Header= "stores", Content = new TableControl { DataContext = stores } });
                    tabItems.Add(new TabItem { Header= "suppliers", Content = new TableControl { DataContext = suppliers } });
                    tabItems.Add(new TabItem { Header = "userInfos", Content = new TableControl { DataContext = userInfos } });
                });
            }
        }

        public RelayCommand BackupCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    Backup(customers, "customers");
                    Backup(goods, "goods");
                    Backup(goodsTypes, "goodsTypes");
                    Backup(inStores, "inStores");
                    Backup(inventories, "inventories");
                    Backup(outStores, "outStores");
                    Backup(specs, "specs");
                    Backup(stores, "stores");
                    Backup(suppliers, "suppliers");
                    Backup(userInfos, "userInfos");
                });
            }
        }

        /// <summary>
        /// 导出数据
        /// </summary>
        /// <param name="array"></param>
        /// <param name="filename"></param>
        /// <exception cref="NotImplementedException"></exception>
        private void Backup<T>(List<T> array, string name)
        {
            var t = typeof(T);
            var properties = t.GetProperties(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
            var contents = new StringBuilder();

            //title
            foreach (var item in properties)
            {
                contents.Append(item.Name);
                contents.Append(",");
            }

            contents.Append("\r\n");

            //content
            foreach (var model in array)
            {
                var row = new StringBuilder();
                foreach (var property in properties)
                {
                    var val = property.GetValue(model);
                    row.Append(val);
                    row.Append(",");
                }
                contents.Append(row.ToString());
                contents.Append("\r\n");
            }

            //finename -> tablename+date
            var date = $"{DateTime.Now.Year}-{DateTime.Now.Month}-{DateTime.Now.Day}-{DateTime.Now.Hour}-{DateTime.Now.Minute}-{DateTime.Now.Second}-{DateTime.Now.Millisecond}";
            var filename = $"{name}{date}.csv";

            //save
            File.WriteAllText(filename, contents.ToString());
            MessageBox.Show("数据导出完成");
        }
    }
}
