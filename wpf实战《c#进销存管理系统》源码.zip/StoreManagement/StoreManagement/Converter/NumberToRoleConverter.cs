﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace StoreManagement.Converter
{
    public class NumberToRoleConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null) return "普通用户";
            if(int.TryParse(value.ToString(), out var number))
            {
                return number == 0 ? "管理员" : "普通用户";
            }
            else
            {
                return "普通用户";
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
