﻿using GalaSoft.MvvmLight;
using StoreManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreManagement
{
    public partial class Inventory : ObservableObject
    {
        public string GoodsTypeName
        {
            get
            {
                if (Id == 0) return string.Empty;
                var model = new GoodsTypeService().Select().FirstOrDefault(t => t.Id == Id);
                if(model == null) return string.Empty;
                return model.Name;
            }
        }

        public string SpecName
        {
            get
            {
                if (Id == 0) return string.Empty;
                var model = new SpecService().Select().FirstOrDefault(t => t.Id == Id);
                if (model == null) return string.Empty;
                return model.Name;
            }
        }



    }
}
