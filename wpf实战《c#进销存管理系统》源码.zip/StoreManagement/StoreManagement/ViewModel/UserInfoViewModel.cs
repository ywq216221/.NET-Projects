﻿using CommonServiceLocator;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using StoreManagement.View;
using StoreManagement.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StoreManagement.ViewModel
{
    public class UserInfoViewModel : ViewModelBase
    {

        private UserInfo userInfo = new UserInfo();
        public UserInfo UserInfo
        {
            get { return userInfo; }
            set { userInfo = value; RaisePropertyChanged(); }
        }

        private List<UserInfo> userInfoList = new List<UserInfo>();

        public List<UserInfo> UserInfoList
        {
            get { return userInfoList; }
            set { userInfoList = value; RaisePropertyChanged(); }
        }


        private ComboBoxItem role = null;
        public ComboBoxItem Role
        {
            get { return role; }
            set { role = value; RaisePropertyChanged(); }
        }


        /// <summary>
        /// 加载页面时获取数据
        /// </summary>
        public RelayCommand LoadCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    UserInfoList = new UserInfoService().Select();
                });
            }
        }


        //添加
        public RelayCommand<UserControl> AddCommand
        {
            get
            {
                var command = new RelayCommand<UserControl>((obj) =>
                {
                    if (!(obj is UserInfoView view)) return;
                    if (string.IsNullOrEmpty(UserInfo.Name) == true
                    || string.IsNullOrEmpty(UserInfo.Password) == true)
                    {
                        MessageBox.Show("用户名和密码不能为空");
                        return;
                    }

                    UserInfo.InsertDate = DateTime.Now;

                    if (Role == null) return;
                    if(int.TryParse(Role.Tag.ToString(),out int result))
                    {
                        UserInfo.Role = result;
                    }
                    else
                    {
                        return;
                    }
                    

                    var service = new UserInfoService();
                    int count = service.Insert(UserInfo);
                    if (count > 0)
                    {
                        UserInfoList = service.Select();
                        MessageBox.Show("操作成功");
                        UserInfo = new UserInfo();
                    }
                    else
                    {
                        MessageBox.Show("操作失败");
                    }
                });

                return command;
            }
        }      

        //删除
        public RelayCommand<Button> DeleteCommand
        {
            get
            {
                var command = new RelayCommand<Button>((view) =>
                {
                    if (MessageBox.Show("是否执行操作?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        var old = view.Tag as UserInfo;
                        if (old == null) return;

                        var service = new UserInfoService();
                        int count = service.Delete(old);
                        if (count > 0)
                        {
                            UserInfoList = service.Select();
                            MessageBox.Show("操作成功");
                        }
                        else
                        {
                            MessageBox.Show("操作失败");
                        }
                    }
                });

                return command;
            }
        }
    }
}
