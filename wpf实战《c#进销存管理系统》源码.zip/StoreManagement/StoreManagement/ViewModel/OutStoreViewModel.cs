﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using StoreManagement.Service;
using StoreManagement.View;
using StoreManagement.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StoreManagement.ViewModel
{
    public class OutStoreViewModel : ViewModelBase
    {
        //添加出库记录
        public RelayCommand<UserControl> AddCommand
        {
            get
            {
                var command = new RelayCommand<UserControl>((obj) =>
                {
                    if (!(obj is OutStoreView view)) return;
                    if (string.IsNullOrEmpty(OutStore.Name) == true
                    || string.IsNullOrEmpty(OutStore.GoodsSerial) == true)
                    {
                        MessageBox.Show("序号和名字不能为空");
                        return;
                    }

                    OutStore.InsertDate = DateTime.Now;
                    OutStore.UserInfoId = AppData.Instance.User.Id;

                    if (Store.Id == 0)
                    {
                        MessageBox.Show("仓库不能为空");
                        return;
                    }

                    if (Customer.Id == 0)
                    {
                        MessageBox.Show("客户不能为空");
                        return;
                    }

                    if (Goods.Quant < OutStore.Number)
                    {
                        MessageBox.Show("存库不足");
                        return;
                    }

                    OutStore.StoreId = Store.Id;
                    OutStore.StoreName = Store.Name;
                    OutStore.CustomerId = Customer.Id;
                    OutStore.CustomerName = Customer.Name;

                    
                    var service = new OutStoreService();
                    int count = service.Insert(OutStore);
                    if (count > 0)
                    {
                        //及时更新当前物资的存量
                        if (Goods != null)
                        {
                            Goods.Quant -= OutStore.Number;
                            GoodsService goodsService = new GoodsService();
                            count = goodsService.Update(this.Goods);
                        }
                        OutStoreList = new OutStoreService().Select();
                        OutStore = new OutStore();
                        MessageBox.Show("操作成功");

                    }
                    else
                    {
                        MessageBox.Show("操作失败");
                    }
                });

                return command;
            }
        }

        //加载数据
        public RelayCommand LoadCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    StoreList = new StoreService().Select();
                    CustomerList = new CustomerService().Select();
                    OutStoreList = new OutStoreService().Select();
                });
            }
        }

        private Store store = new Store();
        /// <summary>
        /// 当前仓库
        /// </summary>
        public Store Store
        {
            get { return store; }
            set { store = value; RaisePropertyChanged(); }
        }

        private List<Store> storeList = new List<Store>();
        /// <summary>
        /// 仓库集合
        /// </summary>
        public List<Store> StoreList
        {
            get { return storeList; }
            set { storeList = value; RaisePropertyChanged(); }
        }





        private Customer customer = new Customer();
        /// <summary>
        /// 当前客户
        /// </summary>
        public Customer Customer
        {
            get { return customer; }
            set { customer = value; RaisePropertyChanged(); }
        }





        private List<Customer> customerList = new List<Customer>();
        /// <summary>
        /// 客户集合
        /// </summary>
        public List<Customer> CustomerList
        {
            get { return customerList; }
            set { customerList = value; RaisePropertyChanged(); }
        }


        private OutStore outstore = new OutStore();
        public OutStore OutStore
        {
            get { return outstore; }
            set { outstore = value; RaisePropertyChanged(); }
        }

        private List<OutStore> outStoreList = new List<OutStore>();
        /// <summary>
        /// 出库历史记录
        /// </summary>
        public List<OutStore> OutStoreList
        {
            get { return outStoreList; }
            set { outStoreList = value; RaisePropertyChanged(); }
        }


        private Goods goods = new Goods();
        /// <summary>
        /// 当前选择的资物对象
        /// </summary>
        public Goods Goods
        {
            get { return goods; }
            set { goods = value; RaisePropertyChanged(); }
        }

        public RelayCommand OpenSelectGoodsWindow
        {
            get
            {
                return new RelayCommand(() =>
                {
                    var window = new SelectGoodsWindow();
                    var result = window.ShowDialog();
                    if (result.HasValue && result.Value == true)
                    {
                        var vm = window.DataContext as SelectGoodsViewModel;
                        OutStore.GoodsSerialEx = vm.Goods.Serial;
                        OutStore.NameEx = vm.Goods.Name;
                        this.Goods = vm.Goods;
                    }
                });
            }
        }
    }
}
