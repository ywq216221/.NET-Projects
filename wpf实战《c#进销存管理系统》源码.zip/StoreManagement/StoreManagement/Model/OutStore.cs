﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreManagement
{
    public partial class OutStore : ObservableObject
    {
        public int IdEx { get { return Id; } set { Id = value;RaisePropertyChanged(); } }
        public string GoodsSerialEx { get { return GoodsSerial; } set { GoodsSerial = value; RaisePropertyChanged(); } }
        public string NameEx { get { return Name; } set { Name = value; RaisePropertyChanged(); } }
        public Nullable<int> StoreIdEx { get { return StoreId; } set { StoreId = value; RaisePropertyChanged(); } }
        public string StoreNameEx { get { return StoreName; } set { StoreName = value; RaisePropertyChanged(); } }
        public int CustomerIdEx { get { return CustomerId; } set { CustomerId = value; RaisePropertyChanged(); } }
        public string CustomerNameEx { get { return CustomerName; } set { CustomerName = value; RaisePropertyChanged(); } }
        public string UnitEx { get { return Unit; } set { Unit = value; RaisePropertyChanged(); } }
        public double NumberEx { get { return Number; } set { Number = value; RaisePropertyChanged(); } }
        public double PriceEx { get { return Price; } set { Price = value; RaisePropertyChanged(); } }
        public Nullable<System.DateTime> InsertDateEx { get { return InsertDate; } set { InsertDate = value; RaisePropertyChanged(); } }
        public Nullable<int> GoodsTypeIdEx { get { return GoodsTypeId; } set { GoodsTypeId = value; RaisePropertyChanged(); } }
        public Nullable<int> UserInfoIdEx { get { return UserInfoId; } set { UserInfoId = value; RaisePropertyChanged(); } }
        public string UserInfoNameEx { get { return UserInfoName; } set { UserInfoName = value; RaisePropertyChanged(); } }
        public string TagEx { get { return Tag; } set { Tag = value; RaisePropertyChanged(); } }
        public Nullable<bool> IsInventoryEx { get { return IsInventory; } set { IsInventory = value; RaisePropertyChanged(); } }
    }
}
