﻿using AutoMapper;
using StoreManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreManagement.AutoMapper.Profiles
{
    public class InStoreExProfile : Profile
    {
        public InStoreExProfile() 
        {
            CreateMap<InStoreEx, InStore>();
        }
    }
}
